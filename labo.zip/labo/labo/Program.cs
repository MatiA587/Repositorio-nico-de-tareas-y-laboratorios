﻿using System;

class Program
{
    static float CalcularBono(string carnet)
    {
        string ultimosDos = carnet.Substring(carnet.Length - 2);
        int numero = int.Parse(ultimosDos);

        float bono = numero * 0.07f;

        return bono;
    }

    static string ObtenerClasificacion(float promedioFinal)
    {
        string clasificacion;

        if (promedioFinal >= 90 && promedioFinal <= 100)
        {
            clasificacion = "Excelente";
        }
        else if (promedioFinal >= 70)
        {
            clasificacion = "Bueno";
        }
        else if (promedioFinal >= 51)
        {
            clasificacion = "Regular";
        }
        else
        {
            clasificacion = "Observado";
        }

        return clasificacion;
    }

    static void Main()
    {
        string nombre;
        string apellido;
        string carnet;
        string carrera;
        int paralelo;
        float nota;
        string materia;

        const int NumAsignaturas = 5;
        const int NotaAprobacion = 51;

        Console.WriteLine("Ingrese el nombre del estudiante:");
        nombre = Console.ReadLine();

        Console.WriteLine("Ingrese el apellido del estudiante:");
        apellido = Console.ReadLine();

        Console.WriteLine("Ingrese el numero de carnet del estudiante:");
        carnet = Console.ReadLine();

        while (carnet.Length < 2)
        {
            Console.WriteLine("El carnet debe tener al menos 2 digitos.");
            Console.WriteLine("Ingrese nuevamente el carnet:");
            carnet = Console.ReadLine();
        }

        Console.WriteLine("Ingrese la carrera del estudiante:");
        carrera = Console.ReadLine();

        Console.WriteLine("Ingrese el paralelo del estudiante:");
        paralelo = int.Parse(Console.ReadLine());

        float sumaNotas = 0;
        int cantidadAprobadas = 0;

        for (int indice = 1; indice <= NumAsignaturas; indice++)
        {
            Console.WriteLine("Ingrese el nombre de la materia:");
            materia = Console.ReadLine();

            Console.WriteLine("Ingrese la nota de " + materia + ":");
            nota = float.Parse(Console.ReadLine());

            while (nota < 0 || nota > 100)
            {
                Console.WriteLine("La nota ingresada es invalida.");
                Console.WriteLine("Ingrese nuevamente la nota:");
                nota = float.Parse(Console.ReadLine());
            }

            if (nota >= NotaAprobacion)
            {
                cantidadAprobadas = cantidadAprobadas + 1;
            }

            sumaNotas = sumaNotas + nota;
        }

        float promedio = sumaNotas / NumAsignaturas;

        float bono = CalcularBono(carnet);

        float promedioFinal = promedio + bono;

        string clasificacion = ObtenerClasificacion(promedioFinal);

        Console.WriteLine();
        Console.WriteLine("------ RESUMEN ACADEMICO ------");
        Console.WriteLine("Nombre: " + nombre);
        Console.WriteLine("Apellido: " + apellido);
        Console.WriteLine("Carnet: " + carnet);
        Console.WriteLine("Carrera: " + carrera);
        Console.WriteLine("Paralelo: " + paralelo);
        Console.WriteLine("Materias aprobadas: " + cantidadAprobadas);

        Console.WriteLine("Promedio original: " + promedio);
        Console.WriteLine("Bono calculado: " + bono);
        Console.WriteLine("Promedio final: " + promedioFinal);
        Console.WriteLine("Clasificacion: " + clasificacion);
    }
}